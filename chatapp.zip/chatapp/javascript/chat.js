const form = document.querySelector(".typing-area"),
inputField = form.querySelector(".input-field"),
sendBtn = form.querySelector(".button"),
chatbox = document.querySelector(".chat-box");

form.onsubmit = (e)=>{
    e.preventDefault();//preventing form from submitting
 }

sendBtn.onclick = ()=>{
     //let's start Ajax
   let xhr = new XMLHttpRequest(); //craeting XML object
   xhr.open("POST", "php/insert-chat.php", true);
   xhr.onload = ()=>{
       if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                inputField.value = "";
                scrollToBottom(); 
           }
       }
   }
   //we have to send the form through ajax to php
   let formData = new FormData(form); //creating new formdata object
   xhr.send(formData); //sending the form data to php
}

chatbox.onmouseenter = ()=>{
    chatbox.classList.add("active");
}
chatbox.onmouseleave = ()=>{
    chatbox.classList.remove("active");
}

setInterval(()=>{
    //let's start Ajax
    let xhr = new XMLHttpRequest(); //creating XML object
    xhr.open("POST", "php/get-chat.php", true);
    xhr.onload = ()=>{
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                let data = xhr.response;
                chatbox.innerHTML = data;
                if(!chatbox.classList.contains("active")){
                    scrollToBottom();
                }
            }
        }
    }
    //we have to send the form through ajax to php
   let formData = new FormData(form); //creating new formdata object
   xhr.send(formData); //sending the form data to php
}, 500);

function scrollToBottom(){
    chatbox.scrollTop = chatbox.scrollHeight;
}